// ─── COLORS ────────────────────────────────────────────────────────────────
export const Colors = {
  bg:       '#0A0F0D',
  bg2:      '#111A16',
  bg3:      '#162019',
  ring:     '#1D3A2A',
  accent:   '#4ADE80',
  accent2:  '#86EFAC',
  text:     '#E8F0EB',
  muted:    '#5A7A65',
  muted2:   '#3A5A45',
  dark:     '#0A0F0D', // text on accent bg
} as const;

// ─── TYPOGRAPHY ────────────────────────────────────────────────────────────
// Load in app.json or via expo-font:
// "DM_Serif_Display" and "DM_Sans"
export const Fonts = {
  serif:       'DMSerifDisplay_400Regular',
  serifItalic: 'DMSerifDisplay_400Regular_Italic',
  sans:        'DMSans_400Regular',
  sansMedium:  'DMSans_500Medium',
  sansLight:   'DMSans_300Light',
} as const;

// ─── SPACING ───────────────────────────────────────────────────────────────
export const Space = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
} as const;

// ─── RADII ─────────────────────────────────────────────────────────────────
export const Radius = {
  sm:   8,
  md:   12,
  lg:   16,
  xl:   20,
  pill: 999,
} as const;

// ─── SOUND LABELS ──────────────────────────────────────────────────────────
export const SOUNDS = {
  bowl:    { label: 'Bowl',     emoji: '🔔', file: require('../assets/sounds/bowl.mp3') },
  rain:    { label: "Yomg'ir", emoji: '🌧️', file: require('../assets/sounds/rain.mp3') },
  river:   { label: 'Daryo',   emoji: '🌊', file: require('../assets/sounds/river.mp3') },
  silence: { label: 'Jim',     emoji: '🤫', file: null },
} as const;

// ─── BREATH CYCLE ──────────────────────────────────────────────────────────
// Classic 4-2-6-2 box breathing
export const BREATH_CYCLE = [
  { text: 'Nafas oling...', sub: '4 soniya', duration: 4000 },
  { text: 'Ushlab turing',  sub: '2 soniya', duration: 2000 },
  { text: 'Nafas chiqaring', sub: '6 soniya', duration: 6000 },
  { text: 'Dam oling',      sub: '2 soniya', duration: 2000 },
] as const;
