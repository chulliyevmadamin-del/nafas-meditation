import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Animated, Easing,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Circle } from 'react-native-svg';
import * as Haptics from 'expo-haptics';
import { Audio } from 'expo-av';
import { Colors, Fonts, Space, Radius, SOUNDS, BREATH_CYCLE } from '../constants/theme';
import type { SessionConfig, SessionResult } from '../App';

interface Props {
  config: SessionConfig;
  onDone: (result: SessionResult) => void;
  onBack: () => void;
}

const RING_RADIUS = 90;
const CIRCUMFERENCE = 2 * Math.PI * RING_RADIUS;

function fmt(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export default function TimerScreen({ config, onDone, onBack }: Props) {
  const insets = useSafeAreaInsets();
  const totalSec = config.durationMin === 0 ? 0 : config.durationMin * 60;

  const [remain, setRemain]     = useState(totalSec || 99 * 60);
  const [elapsed, setElapsed]   = useState(0);
  const [playing, setPlaying]   = useState(true);
  const [breathIdx, setBreathIdx] = useState(0);

  // Refs
  const playingRef  = useRef(true);
  const elapsedRef  = useRef(0);
  const timerRef    = useRef<ReturnType<typeof setInterval> | null>(null);
  const breathRef   = useRef<ReturnType<typeof setTimeout> | null>(null);
  const soundRef    = useRef<Audio.Sound | null>(null);

  // Animated ring scale for breath
  const scale = useRef(new Animated.Value(1)).current;

  // ── Sound ──────────────────────────────────────────────────────────────
  useEffect(() => {
    let mounted = true;
    async function loadSound() {
      const info = SOUNDS[config.sound];
      if (!info.file) return;
      try {
        await Audio.setAudioModeAsync({ playsInSilentModeIOS: true, staysActiveInBackground: true });
        const { sound } = await Audio.Sound.createAsync(info.file, { isLooping: true });
        if (mounted) {
          soundRef.current = sound;
          await sound.playAsync();
        }
      } catch (_) {}
    }
    loadSound();
    return () => {
      mounted = false;
      soundRef.current?.unloadAsync();
    };
  }, []);

  // ── Breath animation ───────────────────────────────────────────────────
  const animateBreath = useCallback((idx: number) => {
    const phase = BREATH_CYCLE[idx % BREATH_CYCLE.length];
    const toScale = (idx % BREATH_CYCLE.length === 0) ? 1.06 : 1;

    Animated.timing(scale, {
      toValue: toScale,
      duration: phase.duration,
      easing: Easing.inOut(Easing.ease),
      useNativeDriver: true,
    }).start();

    breathRef.current = setTimeout(() => {
      setBreathIdx(idx + 1);
      animateBreath(idx + 1);
    }, phase.duration);
  }, [scale]);

  useEffect(() => {
    animateBreath(0);
    return () => { if (breathRef.current) clearTimeout(breathRef.current); };
  }, [animateBreath]);

  // ── Countdown ─────────────────────────────────────────────────────────
  useEffect(() => {
    timerRef.current = setInterval(() => {
      if (!playingRef.current) return;
      elapsedRef.current += 1;
      setElapsed(e => e + 1);

      if (config.durationMin !== 0) {
        setRemain(r => {
          const next = r - 1;
          if (next <= 0) {
            clearInterval(timerRef.current!);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            onDone({ durationMin: config.durationMin, completedSec: totalSec });
          }
          return Math.max(0, next);
        });
      }
    }, 1000);

    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  const togglePlay = () => {
    const next = !playing;
    playingRef.current = next;
    setPlaying(next);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (next) soundRef.current?.playAsync();
    else       soundRef.current?.pauseAsync();
  };

  const handleEnd = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    onDone({ durationMin: config.durationMin, completedSec: elapsedRef.current });
  };

  // Ring progress: 0 → full
  const progress = config.durationMin === 0
    ? (elapsed % 300) / 300
    : 1 - remain / totalSec;
  const strokeDashoffset = CIRCUMFERENCE * (1 - progress);

  const phase = BREATH_CYCLE[breathIdx % BREATH_CYCLE.length];
  const displayTime = config.durationMin === 0 ? fmt(elapsed) : fmt(remain);

  return (
    <View style={[styles.root, { paddingTop: insets.top + Space.md, paddingBottom: insets.bottom + Space.lg }]}>

      {/* Top bar */}
      <View style={styles.topBar}>
        <TouchableOpacity style={styles.backBtn} onPress={onBack}>
          <Text style={styles.backText}>← Orqaga</Text>
        </TouchableOpacity>
        <Text style={styles.soundTag}>
          {SOUNDS[config.sound].emoji} {SOUNDS[config.sound].label}
        </Text>
      </View>

      {/* Ring */}
      <Animated.View style={{ transform: [{ scale }] }}>
        <View style={styles.ringWrap}>
          <Svg width={220} height={220}>
            {/* Track */}
            <Circle
              cx={110} cy={110} r={RING_RADIUS}
              fill="none"
              stroke={Colors.ring}
              strokeWidth={8}
            />
            {/* Progress */}
            <Circle
              cx={110} cy={110} r={RING_RADIUS}
              fill="none"
              stroke={Colors.accent}
              strokeWidth={8}
              strokeLinecap="round"
              strokeDasharray={CIRCUMFERENCE}
              strokeDashoffset={strokeDashoffset}
              rotation={-90}
              origin="110, 110"
            />
          </Svg>
          <View style={styles.ringCenter}>
            <Text style={styles.timerDigits}>{displayTime}</Text>
            <Text style={styles.timerPhase}>
              {config.durationMin === 0 ? 'Erkin sessiya' : 'Qoldi'}
            </Text>
          </View>
        </View>
      </Animated.View>

      {/* Breath guide */}
      <View style={styles.breathWrap}>
        <Text style={styles.breathText}>{phase.text}</Text>
        <Text style={styles.breathSub}>{phase.sub}</Text>
      </View>

      {/* Controls */}
      <View style={styles.controls}>
        {/* +10 sec */}
        <TouchableOpacity
          style={styles.sideBtn}
          onPress={() => { setRemain(r => r + 10); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
        >
          <Text style={styles.sideBtnText}>+10s</Text>
        </TouchableOpacity>

        {/* Play / Pause */}
        <TouchableOpacity style={styles.mainBtn} onPress={togglePlay} activeOpacity={0.85}>
          <Text style={styles.mainBtnIcon}>{playing ? '⏸' : '▶'}</Text>
        </TouchableOpacity>

        {/* End */}
        <TouchableOpacity style={styles.sideBtn} onPress={handleEnd}>
          <Text style={styles.sideBtnText}>✓</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.bg,
    paddingHorizontal: Space.lg,
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  // Top bar
  topBar: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backBtn: {
    backgroundColor: Colors.bg2,
    borderWidth: 1,
    borderColor: Colors.ring,
    borderRadius: Radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  backText: {
    fontFamily: Fonts.sans,
    fontSize: 12,
    color: Colors.muted,
  },
  soundTag: {
    fontFamily: Fonts.sans,
    fontSize: 12,
    color: Colors.muted,
  },

  // Ring
  ringWrap: {
    width: 220,
    height: 220,
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  ringCenter: {
    position: 'absolute',
    alignItems: 'center',
  },
  timerDigits: {
    fontFamily: Fonts.serif,
    fontSize: 52,
    color: Colors.text,
    letterSpacing: -1,
  },
  timerPhase: {
    fontFamily: Fonts.sansLight,
    fontSize: 11,
    color: Colors.muted,
    letterSpacing: 0.8,
    marginTop: 4,
    textTransform: 'uppercase',
  },

  // Breath
  breathWrap: { alignItems: 'center', gap: 6 },
  breathText: {
    fontFamily: Fonts.serif,
    fontSize: 22,
    color: Colors.accent2,
    letterSpacing: 0.3,
  },
  breathSub: {
    fontFamily: Fonts.sansLight,
    fontSize: 12,
    color: Colors.muted,
  },

  // Controls
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
  },
  sideBtn: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: Colors.bg2,
    borderWidth: 1,
    borderColor: Colors.ring,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sideBtnText: {
    fontFamily: Fonts.sans,
    fontSize: 13,
    color: Colors.muted,
  },
  mainBtn: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: Colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mainBtnIcon: {
    fontSize: 24,
    color: Colors.dark,
  },
});
