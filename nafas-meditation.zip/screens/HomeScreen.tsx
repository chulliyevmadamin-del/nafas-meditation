import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors, Fonts, Space, Radius, SOUNDS } from '../constants/theme';
import type { SessionConfig } from '../App';

interface Props {
  onStart: (config: SessionConfig) => void;
}

const DURATIONS = [
  { min: 5,  label: '5',  sub: 'daqiqa' },
  { min: 10, label: '10', sub: 'daqiqa' },
  { min: 15, label: '15', sub: 'daqiqa' },
  { min: 20, label: '20', sub: 'daqiqa' },
  { min: 30, label: '30', sub: 'daqiqa' },
  { min: 0,  label: '∞',  sub: 'erkin'  },
];

type SoundKey = keyof typeof SOUNDS;

export default function HomeScreen({ onStart }: Props) {
  const insets = useSafeAreaInsets();
  const [duration, setDuration] = useState(5);
  const [sound, setSound] = useState<SoundKey>('bowl');

  // Greeting based on hour
  const hour = new Date().getHours();
  const greeting =
    hour < 12 ? 'Xayrli tong' :
    hour < 17 ? 'Xayrli kun' :
                'Xayrli kech';

  return (
    <ScrollView
      style={styles.root}
      contentContainerStyle={[styles.content, { paddingTop: insets.top + Space.lg }]}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.greeting}>{greeting}</Text>
        <Text style={styles.title}>{'Bugun qancha\nmeditatsiya?'}</Text>
        {/* Streak pill — replace 7 with AsyncStorage value */}
        <View style={styles.streakPill}>
          <Text style={styles.streakFire}>🔥</Text>
          <Text style={styles.streakText}>7 kunlik streak</Text>
        </View>
      </View>

      {/* Duration */}
      <View style={styles.section}>
        <Text style={styles.sectionLabel}>DAVOMIYLIK</Text>
        <View style={styles.durationGrid}>
          {DURATIONS.map((d) => {
            const selected = duration === d.min;
            return (
              <TouchableOpacity
                key={d.min}
                style={[styles.durCard, selected && styles.durCardSel]}
                onPress={() => setDuration(d.min)}
                activeOpacity={0.75}
              >
                <Text style={[styles.durMin, selected && styles.durMinSel]}>
                  {d.label}
                </Text>
                <Text style={styles.durSub}>{d.sub}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      {/* Sound */}
      <View style={styles.section}>
        <Text style={styles.sectionLabel}>FON TOVUSHI</Text>
        <View style={styles.soundRow}>
          {(Object.keys(SOUNDS) as SoundKey[]).map((key) => {
            const s = SOUNDS[key];
            const selected = sound === key;
            return (
              <TouchableOpacity
                key={key}
                style={[styles.soundCard, selected && styles.soundCardSel]}
                onPress={() => setSound(key)}
                activeOpacity={0.75}
              >
                <Text style={styles.soundEmoji}>{s.emoji}</Text>
                <Text style={[styles.soundLabel, selected && styles.soundLabelSel]}>
                  {s.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      {/* Start */}
      <TouchableOpacity
        style={[styles.startBtn, { marginBottom: insets.bottom + Space.lg }]}
        onPress={() => onStart({ durationMin: duration, sound })}
        activeOpacity={0.85}
      >
        <Text style={styles.startText}>Boshlash</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  content: {
    paddingHorizontal: Space.lg,
    paddingBottom: Space.lg,
    gap: Space.xl,
  },

  // Header
  header: { gap: Space.sm },
  greeting: {
    fontFamily: Fonts.sansLight,
    fontSize: 14,
    color: Colors.muted,
    letterSpacing: 0.4,
  },
  title: {
    fontFamily: Fonts.serif,
    fontSize: 30,
    color: Colors.text,
    lineHeight: 38,
  },
  streakPill: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 6,
    backgroundColor: Colors.bg3,
    borderWidth: 1,
    borderColor: Colors.ring,
    borderRadius: Radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 7,
    marginTop: 4,
  },
  streakFire: { fontSize: 14 },
  streakText: {
    fontFamily: Fonts.sans,
    fontSize: 12,
    color: Colors.accent2,
  },

  // Section
  section: { gap: Space.sm },
  sectionLabel: {
    fontFamily: Fonts.sans,
    fontSize: 10,
    color: Colors.muted2,
    letterSpacing: 1,
  },

  // Duration grid
  durationGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  durCard: {
    width: '30.5%',
    backgroundColor: Colors.bg2,
    borderWidth: 1,
    borderColor: Colors.ring,
    borderRadius: Radius.lg,
    paddingVertical: 14,
    alignItems: 'center',
  },
  durCardSel: {
    backgroundColor: Colors.bg3,
    borderColor: Colors.accent,
  },
  durMin: {
    fontFamily: Fonts.serif,
    fontSize: 24,
    color: Colors.text,
  },
  durMinSel: { color: Colors.accent },
  durSub: {
    fontFamily: Fonts.sansLight,
    fontSize: 10,
    color: Colors.muted,
    marginTop: 2,
  },

  // Sound
  soundRow: {
    flexDirection: 'row',
    gap: 8,
  },
  soundCard: {
    flex: 1,
    backgroundColor: Colors.bg2,
    borderWidth: 1,
    borderColor: Colors.ring,
    borderRadius: Radius.md,
    paddingVertical: 10,
    alignItems: 'center',
    gap: 4,
  },
  soundCardSel: {
    backgroundColor: Colors.bg3,
    borderColor: Colors.accent2,
  },
  soundEmoji: { fontSize: 18 },
  soundLabel: {
    fontFamily: Fonts.sans,
    fontSize: 10,
    color: Colors.muted,
  },
  soundLabelSel: { color: Colors.accent2 },

  // Start button
  startBtn: {
    backgroundColor: Colors.accent,
    borderRadius: Radius.xl,
    paddingVertical: 18,
    alignItems: 'center',
  },
  startText: {
    fontFamily: Fonts.sansMedium,
    fontSize: 17,
    color: Colors.dark,
    letterSpacing: 0.3,
  },
});
