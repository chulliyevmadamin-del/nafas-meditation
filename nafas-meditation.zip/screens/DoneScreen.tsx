import React, { useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Animated, Easing,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import { Colors, Fonts, Space, Radius } from '../constants/theme';
import type { SessionResult } from '../App';

interface Props {
  result: SessionResult;
  onAgain: () => void;
}

interface Stats {
  streak: number;
  totalMin: number;
  todaySessions: number;
}

export default function DoneScreen({ result, onAgain }: Props) {
  const insets = useSafeAreaInsets();
  const [stats, setStats] = React.useState<Stats>({ streak: 0, totalMin: 0, todaySessions: 0 });

  // Entry animation
  const fadeAnim  = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    Animated.parallel([
      Animated.timing(fadeAnim,  { toValue: 1, duration: 600, easing: Easing.out(Easing.ease), useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 500, easing: Easing.out(Easing.back(1.2)), useNativeDriver: true }),
    ]).start();

    updateStats();
  }, []);

  const updateStats = async () => {
    try {
      const today = new Date().toISOString().slice(0, 10);
      const completedMin = Math.max(1, Math.round(result.completedSec / 60));

      const raw = await AsyncStorage.getItem('meditation_stats');
      const saved = raw ? JSON.parse(raw) : { streak: 0, totalMin: 0, lastDate: '', todaySessions: 0, todayDate: '' };

      // Streak logic
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yStr = yesterday.toISOString().slice(0, 10);

      let newStreak = saved.lastDate === yStr ? saved.streak + 1
                    : saved.lastDate === today ? saved.streak
                    : 1;

      const todaySessions = saved.todayDate === today ? saved.todaySessions + 1 : 1;

      const updated = {
        streak: newStreak,
        totalMin: (saved.totalMin || 0) + completedMin,
        lastDate: today,
        todaySessions,
        todayDate: today,
      };

      await AsyncStorage.setItem('meditation_stats', JSON.stringify(updated));
      setStats({ streak: newStreak, totalMin: updated.totalMin, todaySessions });
    } catch (_) {}
  };

  const completedMin = Math.max(1, Math.round(result.completedSec / 60));

  const motivational = completedMin >= 20
    ? 'Ajoyib sessiya!'
    : completedMin >= 10
    ? 'Yaxshi bo\'ldi.'
    : 'Har kun bir qadam.';

  return (
    <Animated.View
      style={[
        styles.root,
        { paddingTop: insets.top + Space.lg, paddingBottom: insets.bottom + Space.lg },
        { opacity: fadeAnim, transform: [{ translateY: slideAnim }] },
      ]}
    >
      {/* Emoji badge */}
      <View style={styles.center}>
        <View style={styles.badge}>
          <Text style={styles.badgeEmoji}>🧘</Text>
        </View>
        <Text style={styles.title}>{motivational}</Text>
        <Text style={styles.subtitle}>
          Bugun{' '}
          <Text style={styles.accentText}>{completedMin} daqiqa</Text>
          {' '}meditatsiya qildingiz.{'\n'}
          Har kun bir oz — hayot o'zgaradi.
        </Text>
      </View>

      {/* Stats */}
      <View style={styles.statRow}>
        <View style={styles.statCard}>
          <Text style={styles.statVal}>{stats.streak}</Text>
          <Text style={styles.statLbl}>🔥 Streak</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statVal}>{stats.totalMin}</Text>
          <Text style={styles.statLbl}>⏱ Jami daqiqa</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statVal}>{stats.todaySessions}</Text>
          <Text style={styles.statLbl}>📅 Bugun</Text>
        </View>
      </View>

      {/* Actions */}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.againBtn} onPress={onAgain} activeOpacity={0.85}>
          <Text style={styles.againText}>Yana bir sessiya</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.homeLink} onPress={onAgain}>
          <Text style={styles.homeLinkText}>Asosiy sahifaga qaytish</Text>
        </TouchableOpacity>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: Colors.bg,
    paddingHorizontal: Space.lg,
    justifyContent: 'space-between',
  },

  center: { alignItems: 'center', gap: Space.md, flex: 1, justifyContent: 'center' },

  badge: {
    width: 100, height: 100, borderRadius: 50,
    backgroundColor: Colors.bg3,
    borderWidth: 2, borderColor: Colors.accent,
    alignItems: 'center', justifyContent: 'center',
  },
  badgeEmoji: { fontSize: 44 },

  title: {
    fontFamily: Fonts.serif,
    fontSize: 30,
    color: Colors.text,
    textAlign: 'center',
  },
  subtitle: {
    fontFamily: Fonts.sansLight,
    fontSize: 14,
    color: Colors.muted,
    textAlign: 'center',
    lineHeight: 22,
  },
  accentText: {
    fontFamily: Fonts.sansMedium,
    color: Colors.accent2,
  },

  // Stats
  statRow: { flexDirection: 'row', gap: Space.sm },
  statCard: {
    flex: 1,
    backgroundColor: Colors.bg2,
    borderWidth: 1, borderColor: Colors.ring,
    borderRadius: Radius.lg,
    paddingVertical: Space.md,
    alignItems: 'center', gap: 4,
  },
  statVal: {
    fontFamily: Fonts.serif,
    fontSize: 28,
    color: Colors.accent2,
  },
  statLbl: {
    fontFamily: Fonts.sansLight,
    fontSize: 10,
    color: Colors.muted,
    textAlign: 'center',
  },

  // Actions
  actions: { gap: Space.sm },
  againBtn: {
    backgroundColor: Colors.accent,
    borderRadius: Radius.xl,
    paddingVertical: 17,
    alignItems: 'center',
  },
  againText: {
    fontFamily: Fonts.sansMedium,
    fontSize: 16,
    color: Colors.dark,
  },
  homeLink: { paddingVertical: Space.sm, alignItems: 'center' },
  homeLinkText: {
    fontFamily: Fonts.sansLight,
    fontSize: 13,
    color: Colors.muted,
  },
});
