# 🧘 Nafas — Meditatsiya Taymeri

> Reklama yo'q. Obuna yo'q. Avtomatik to'lov yo'q.  
> Faqat siz va nafas — bir marta to'lang, abadiy ishlating.

![Platform](https://img.shields.io/badge/platform-iOS%20%7C%20Android-lightgrey?style=flat-square)
![Built with](https://img.shields.io/badge/built%20with-Expo%2052-blue?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-green?style=flat-square)
![Status](https://img.shields.io/badge/status-MVP%20in%20progress-orange?style=flat-square)

---

## Nima uchun bu ilova?

Calm, Headspace va Insight Timer — ularning barchasi bir muammodan aziyat chekadi:

| Muammo | Calm | Headspace | Insight Timer |
|---|---|---|---|
| Yashirin auto-renewal | ✗ | ✗ | — |
| Hamma narsa paywall ortida | — | ✗ | — |
| Timer topish qiyin | — | — | ✗ |
| Reklama va upsell | ✗ | — | ✗ |
| Trustpilot baholash | 1.7★ | 1.5★ | 3.8★ |

**Nafas** shu muammolarning teskarisi:

- ✅ Bir martalik **$4.99** — hech qachon obuna emas
- ✅ Timer — birinchi ekranda, izlashga hojat yo'q
- ✅ Ilova ichida **nol reklama**
- ✅ Bekor qilish yo'q — chunki obuna yo'q

---

## Ekranlar

```
┌─────────────────┐   ┌─────────────────┐   ┌─────────────────┐
│  🏠 Bosh sahifa  │   │  ⏱ Taymer        │   │  ✅ Tugadi       │
│                 │   │                 │   │                 │
│  Davomiylik:    │   │     05:00       │   │       🧘         │
│  5  10  15      │   │   ╭───────╮     │   │                 │
│  20  30  ∞      │   │   │ Ring  │     │   │  Yaxshi bo'ldi. │
│                 │   │   ╰───────╯     │   │                 │
│  Tovush:        │   │                 │   │  7 kun streak   │
│  🔔 🌧️ 🌊 🤫   │   │  Nafas oling.. │   │  142 daqiqa     │
│                 │   │                 │   │                 │
│  [ Boshlash ]   │   │   ↩   ⏸   ✓   │   │  [ Yana bir ]   │
└─────────────────┘   └─────────────────┘   └─────────────────┘
```

---

## Texnik stack

```
meditation-app/
├── App.tsx                    # Navigatsiya + type'lar
├── constants/
│   └── theme.ts               # Ranglar, fontlar, spacing
├── screens/
│   ├── HomeScreen.tsx         # Davomiylik + tovush tanlash
│   ├── TimerScreen.tsx        # Ring animatsiyasi + nafas sikli
│   └── DoneScreen.tsx         # Statistika + streak
└── assets/
    └── sounds/                # bowl.mp3, rain.mp3, river.mp3
```

| Texnologiya | Maqsad | Narx |
|---|---|---|
| **Expo 52** | Kross-platforma (iOS + Android) | Bepul |
| **expo-av** | Fon tovushi (silent mode bilan) | Bepul |
| **expo-haptics** | Vibro feedback | Bepul |
| **react-native-svg** | Doira progress ring | Bepul |
| **AsyncStorage** | Streak va statistika | Bepul |
| **EAS Build** | App Store / Play Store build | Bepul |
| **RevenueCat** | In-app purchase ($4.99) | Bepul — 2,500 foydalanuvchigacha |
| **PostHog** | Analytics | Bepul — 1M event/oy |

**Jami dastlabki xarajat: $99/yil** (faqat Apple Developer akkaunti)

---

## Dizayn tizimi

```
Ranglar:
  Fon (asosiy):   #0A0F0D  — O'rmon tuni
  Fon (karta):    #111A16
  Accent:         #4ADE80  — Yashil nafas
  Accent (och):   #86EFAC
  Matn:           #E8F0EB
  O'chiq:         #5A7A65

Fontlar:
  DM Serif Display  — Sarlavhalar (issiqlik)
  DM Sans           — Matn (aniqlik)

Nafas sikli (4-2-6-2):
  Nafas oling    → 4 soniya
  Ushlab turing  → 2 soniya
  Nafas chiqaring → 6 soniya
  Dam oling      → 2 soniya
```

---

## Haftalik reja (MVP)

```
1-kun (Dushanba)   Figma dizayn + Expo setup + tovush fayllar
2-kun (Seshanba)   HomeScreen — davomiylik va tovush tanlash
3-kun (Chorshanba) Backend — Supabase + auth + sessiya saqlash
4-kun (Payshanba)  TimerScreen + DoneScreen + statistika
5-kun (Juma)       RevenueCat to'lov + EAS build (TestFlight)
6-kun (Shanba)     Landing page + Reddit / Product Hunt post
7-kun (Yakshanba)  App Store submit + birinchi foydalanuvchilar
```

---

## Ishga tushirish

### Talablar

- Node.js 18+
- iOS uchun: Xcode 15+ va Apple Developer ($99/yil)
- Android uchun: Android Studio

### O'rnatish

```bash
# 1. Klonlash
git clone https://github.com/USERNAME/nafas-meditation.git
cd nafas-meditation

# 2. Paketlarni o'rnatish
npm install

# 3. Tovush fayllarini joylash
# freesound.org dan yuklab, assets/sounds/ ga qo'ying:
#   bowl.mp3  — "singing bowl meditation" deb qidiring
#   rain.mp3  — "gentle rain ambience"
#   river.mp3 — "river stream nature"

# 4. Ishga tushirish
npx expo start
# Telefonda: Expo Go ilovasini yuklab, QR skanerlang
```

### Haqiqiy qurilmaga build

```bash
npm install -g eas-cli
eas login
eas build:configure

# iOS (TestFlight)
eas build --platform ios --profile preview

# Android
eas build --platform android --profile preview

# App Store production
eas build --platform ios --profile production
```

---

## Monetizatsiya modeli

```
Bepul tier:
  ✓ Kuniga 3 ta sessiya
  ✓ 5 va 10 daqiqa taymeri
  ✓ Bowl tovushi

Pro ($4.99 — bir martalik, abadiy):
  ✓ Cheksiz sessiyalar
  ✓ Barcha davomiyliklar: 15 / 20 / 30 / ∞
  ✓ Barcha tovushlar: yomg'ir, daryo, jim
  ✓ Streak tarixi va statistika
  ✓ Kelajakdagi yangilanishlar bepul
```

### Moliyaviy maqsadlar

| Muddat | Yuklab olish | Pro foydalanuvchi | Jami daromad |
|---|---|---|---|
| 1-oy | 500 | 50 | $250 |
| 3-oy | 2,000 | 200 | $1,000 |
| 6-oy | 5,000 | 500 | $2,500 |

---

## Yo'l xaritasi

### v1.0 — MVP (1-hafta)
- [x] Dizayn (Figma prototip)
- [x] HomeScreen — davomiylik + tovush
- [x] TimerScreen — ring + nafas sikli + tovush
- [x] DoneScreen — statistika + streak
- [ ] RevenueCat integratsiyasi
- [ ] EAS Build + TestFlight
- [ ] App Store submit

### v1.1 — Foydalanuvchi fikri asosida
- [ ] Push notification — kunlik eslatma
- [ ] Haftalik statistika grafigi
- [ ] Yangi tovushlar (o'rmon, shamol)
- [ ] Apple Watch widget

### v2.0 — O'sish bosqichi
- [ ] iCloud sync — qurilmalar o'rtasida
- [ ] Themed sessiyalar (ertalab, kechqurun, ish uchun)
- [ ] Familia rejimi

---

## Hissa qo'shish

Xato topib yoki g'oyangiz bormi?

1. [Issue oching](../../issues)
2. Fork qiling → branch → PR

---

## Litsenziya

MIT — bepul ishlating, o'zgartiring, tarqating.

---

<sub>Raqobatchilar reklama bilan meditatsiyangizni buzadi. Nafas — faqat nafas.</sub>
