import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import HomeScreen from './screens/HomeScreen';
import TimerScreen from './screens/TimerScreen';
import DoneScreen from './screens/DoneScreen';

export type Screen = 'home' | 'timer' | 'done';

export interface SessionConfig {
  durationMin: number; // 0 = infinite
  sound: 'bowl' | 'rain' | 'river' | 'silence';
}

export interface SessionResult {
  durationMin: number;
  completedSec: number;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [config, setConfig] = useState<SessionConfig>({ durationMin: 5, sound: 'bowl' });
  const [result, setResult] = useState<SessionResult>({ durationMin: 5, completedSec: 300 });

  const handleStart = (cfg: SessionConfig) => {
    setConfig(cfg);
    setScreen('timer');
  };

  const handleDone = (res: SessionResult) => {
    setResult(res);
    setScreen('done');
  };

  const handleHome = () => setScreen('home');

  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      {screen === 'home' && <HomeScreen onStart={handleStart} />}
      {screen === 'timer' && <TimerScreen config={config} onDone={handleDone} onBack={handleHome} />}
      {screen === 'done' && <DoneScreen result={result} onAgain={handleHome} />}
    </SafeAreaProvider>
  );
}
